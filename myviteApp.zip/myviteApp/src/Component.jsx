import React from 'react'

export function Component1(){
    return(
        <div>Component-1</div>
    )
}
export function Component2(){
    return(
        <div>Component-2</div>
    )
}
export function Component3(){
    return(
        <div>Component-3</div>
    )
}
export function Component4(){
    return(
        <div>Component-4</div>
    )
}
export function Component5(){
    return(
        <div>Component-5</div>
    )
}
export default Component;