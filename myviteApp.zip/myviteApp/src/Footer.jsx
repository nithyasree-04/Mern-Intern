const Footer = () => {
    return (
        <div>
        <div>
            
        </div>    

        </div>
    );
};

export default Footer;