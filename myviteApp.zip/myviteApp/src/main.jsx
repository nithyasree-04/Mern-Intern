import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import Header from './Header.jsx' 
import Footer from './Footer.jsx'  
import Content from './Content.jsx'
import Component from './Component.jsx'  //from Header.jsx

createRoot(document.getElementById('root')).render(
  <>
<App></App>
</>
    // on giving this content in header.jsx will be displayed as output
)
