const mongoose = require("mongoose")

async function DB(){
 try {
    await mongoose.connect("mongodb://localhost:27017/coursesdata")
    console.log("db connected");
 } catch (error) {
    console.log("error in the connection");
 }
}

module.exports = DB 