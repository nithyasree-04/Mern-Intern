const express = require("express")
const app = express()
const cors = require("cors")
const DB = require("./DB/db")
const courseSchema = require("./models/schema")

app.use(cors())
app.get("/api/v1/search",async (req,res)=>{
       await DB() 
       let query = req.query.search
       let coursedata = await courseSchema.find({title:{$regex:query,$options:"i"}})
       console.log(query);
       res.json(coursedata)
})

app.listen(3000,()=>{
    console.log("server is running");   
})