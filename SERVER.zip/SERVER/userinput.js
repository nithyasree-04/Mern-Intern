// const os = require("os")

// //home directory
// console.log(os.homedir());

// //temp directory
// console.log(os.tmpdir());

// //cpus
// console.log(os.cpus());

// //architecture
// console.log(os.arch());

// //platform(windows)
// console.log(os.platform());

// //version
// console.log(os.version());

// //device name
// console.log(os.hostname());

const path =require("path")

// console.log(__dirname);
// console.log(__filename);
// console.log(path.basename("C:\Users\DELL\Desktop\MERN\SERVER\userinput.js"));
// console.log(path.extname("sample.txt"));
// console.log(path.join("folder","userinput.js"));
console.log(path.parse("C:\Users\DELL\Desktop\MERN\SERVER\index.js"));

