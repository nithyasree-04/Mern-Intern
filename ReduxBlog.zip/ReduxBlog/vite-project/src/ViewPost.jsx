import React from 'react'
import { useSelector } from "react-redux"
import { Link } from 'react-router-dom'
import './index.css'

function ViewPost() {
    const posts = useSelector(state => state.post)
    
    return (
        <div className="view-posts">
            <div className="header">
                <h1>Blog Posts</h1>
                <Link to="/create" className="create-button">Create New Post</Link>
            </div>
            <div className="posts-container">
                {posts.map((post) => (
                    <div key={post.id} className="post-card">
                        <h2>{post.author}'s Post</h2>
                        <p>{post.data}</p>
                        <div className="author-info">
                            <span className="author-label">Written by</span>
                            <span className="author-name">{post.author}</span>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    )
}

export default ViewPost