import {createSlice} from "@reduxjs/toolkit"

const initialState = [{
    id:1,
    author:"Smith",
    data:"lorem epsum ......"
},
{
    id:2,
    author:"Smith",
    data:"lorem epsum ......"
},
{
    id:3,
    author:"Smith",
    data:"lorem epsum ......"
},
{
    id:4,
    author:"Smith",
    data:"lorem epsum ......"
},
{
    id:5,
    author:"Smith",
    data:"lorem epsum ......"
}
]

const post = createSlice({
    name: "post",
    initialState,
    reducers: {
        addPost: (state, action) => {
            state.unshift({
                id: state.length + 1,
                author: action.payload.author,
                data: action.payload.data
            })
        }
    }
})

export const { addPost } = post.actions
export default post.reducer