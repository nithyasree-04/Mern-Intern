import { configureStore } from "@reduxjs/toolkit";
import postReducer from "../Slice/blogslice.js";

const store = configureStore({
    reducer: {
        post: postReducer
    }
});

export default store;
