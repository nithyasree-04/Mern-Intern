import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom"
import CreatePost from './CreatePost'
import ViewPost from './ViewPost'

function App() {
    return (
        <BrowserRouter>
            <Routes>
                <Route path="/" element={<Navigate to="/posts" />} />
                <Route path='/posts' element={<ViewPost/>} />
                <Route path='/create' element={<CreatePost/>} />
            </Routes>
        </BrowserRouter>
    )
}

export default App