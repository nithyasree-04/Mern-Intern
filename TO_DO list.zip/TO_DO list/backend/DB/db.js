const mongoose = require("mongoose")

async function DB(){
    await mongoose.connect("mongodb://localhost:27017/todo")
    console.log("COnnected to Db");
}

module.exports = DB