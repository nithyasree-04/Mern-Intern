import React from "react"
// import Header from "./Header"
import Counter from "./counter/Counter"
// import {Footer} from "./Footer"
// import {Content} from "./Content"
// import Component1 from "./Components"
// import {Component2,Component3,Component4,Component5} from "./Components"
// import {ApiCall} from "./ApiCall"
// import ToDo from "./ToDo"
// import { BrowserRouter, Routes, Route} from "react-router-dom"
// import { useParams } from "react-router-dom"
// import Home from "./Home"
// import Contact from "./Contact"
// import About from "./About"
// import OldBook from "./OldBook"
// import NewBook from "./NewBook"
// import User from "./User"
// import { Link } from "react-router-dom"
function App() 
 {
  
//   function getData(data)
//   {
//     console.log(data)
//   }
  return (
    <>
      {/* <BrowserRouter>
      <ul>
        <li> < a href = '\home'> Home</a></li>
        <li> < a href = '\about'> About</a> </li>
        <li> < a href = '\contact'> Contact</a> </li>
        <li> < Link to = '/home'> Home</Link></li>
        <li> < Link to = '/about'> About</Link> </li>
        <li> < Link to = '/contact'> Contact</Link> </li>
      </ul>
      <Routes>
        <Route path = '/home' element = {
          <Home/>
        }/>

        <Route path = '/about' element = {
          <About/>
        }/>

        <Route path = '/contact' element = {
          <Contact/>
        }/>
        <Route path = '/books'>
          
        <Route path = 'newbooks' element = {
          <NewBook/>}/>
          <Route path = 'oldbooks' element = {
            <OldBook/>}/>

        </Route>

        <Route path = '/user/:id' element = {<User/>}/>
          </Routes>
          </BrowserRouter> */}

          {/* <Header/> */}
          <Counter/>
          
    </>
    )
  }

export {App}

