import React from 'react'

function OldBook() {
  return (
    <div>OldBook</div>
  )
}

export default OldBook