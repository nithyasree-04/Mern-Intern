// import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
// import './app.css'
// import {App} from './App.jsx'
// // import MyContext from './ContextAPI.jsx'

// // let data = "global data"
// createRoot(document.getElementById('root')).render(
//   // <MyCo+99/fds-text.Provider value ={data}>
//     <App/>
//   // </MyContext.Provider> 
// )
import {App} from "./App"
import {Provider} from "react-redux"
import store from "../reduxStore/store"
createRoot(document.getElementById('root')).render(
  <Provider store = {store}>
    <App/>
  </Provider>
)
// import { StrictMode } from 'react'
// import { createRoot } from 'react-dom/client'
// import './Main.css'
// import {App} from './App.jsx'
// createRoot(document.getElementById('root')).render(
//     <StrictMode>
//         <App/>
//     </StrictMode>
// )

// main.jsx