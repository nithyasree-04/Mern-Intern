import React from 'react'
import Form from './Form'

function Home() {
  return (
    // <div className = 'flex bg-black text-white m-10 rounded-lg flex-col'> 
    //     <div className = 'bg-red-500'></div>
    //     <h1 className = 'bg-teal-400 w-10 h-20 font - serif text-purple-500 underline decoration-orange-50 rounded-lg ring-1 border-2 border-red-500 shadow-md shadow-orange-600 '>Hello</h1>
    // </div>
    <div>
        <Form/>
    </div>
  )
}

export default Home
